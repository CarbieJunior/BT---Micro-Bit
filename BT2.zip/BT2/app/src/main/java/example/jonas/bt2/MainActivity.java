package example.jonas.bt2;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ClipData;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    Button b_On, b_Off, b_disc, b_list, popup_list;
    ListView list;


    private static final int REQUEST_ENABLED = 0;
    private static final int REQUEST_DISCOVERABLE = 0;

    BluetoothAdapter bluetoothAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        b_On = (Button) findViewById(R.id.b_On);
        b_Off = (Button) findViewById(R.id.b_Off);
        b_disc = (Button) findViewById(R.id.b_disc);
        b_list = (Button) findViewById(R.id.b_list);
        popup_list = Button findViewById(R.id.popup_list);

        list = (ListView) findViewById(R.id.list);


        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();


        //check if bluetooth is supported
        if(bluetoothAdapter == null){
            Toast.makeText(this, "BlueTooth not Supported!", Toast.LENGTH_SHORT).show();
            finish();
        }

        b_On.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Turns on Bluetooth
                Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(intent, REQUEST_ENABLED);
                Toast.makeText(this, "On", Toast.LENGTH_SHORT).show();

            }
        });
        b_Off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //turns off Bluetooth
                bluetoothAdapter.disable();
                Toast.makeText(this, "Off", Toast.LENGTH_SHORT).show();

            }
        });
        b_disc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Makes the device Discoverable
                if(!bluetoothAdapter.isDiscovering()){
                    Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                    startActivityForResult(intent, REQUEST_DISCOVERABLE);
                }

            }
        });
        b_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final PopupMenu popupMenu = new PopupMenu(MainActivity.this, button);

                Toast.makeText(this, "list", Toast.LENGTH_SHORT).show();
                //list paired devices
                Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();

                ArrayList<String> deviced = new ArrayList<String>();

                for(BluetoothDevice bt : pairedDevices){
                    deviced.add(bt.getName());

                }

                ArrayAdapter arrayAdapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, deviced);

                list.setAdapter(arrayAdapter);
            }
        });



    }

}
